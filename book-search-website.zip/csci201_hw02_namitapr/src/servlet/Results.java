package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Results
 */
@WebServlet("/Results")
public class Results extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response){
	    	String id = request.getParameter("id");
	    	String search = request.getParameter("search");
	    	
	    	try {
	    	 	HttpSession session=request.getSession();
		    	session.setAttribute("id", id);
		    	session.setAttribute("search", search);
		    	PrintWriter out=response.getWriter();
		    request.getRequestDispatcher("ResultsPage.jsp").include(request, response);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ServletException e) {
				e.printStackTrace();
			}
	}
}
